package com.amazon.constants;

public class Constants {


	/** The Constant COLON. */
	public static final String COLON = ":";
	
	/** The Constant UNDERSCORE. */
	public static final String UNDERSCORE = "_";
	
	/** The Constant STEP_DEFINITIONS. */
	public static final String STEP_DEFINITIONS = "com.amazon.steps";
		
	/** The Constant END_TO_END_FEATURES_PATH. */
	public static final String END_TO_END_FEATURES_PATH = "src/test/resources/features";
	
	/** The Constant APPURL. */
	public static final String APPURL = "APPURL";
	
	/** The Constant CONFIG_PROPERTY. */
	public static final String CONFIG_PROPERTY = "\\src\\test\\resources\\config\\config.property";
	
	/** The Constant USER_DIR. */
	public static final String USER_DIR = "user.dir";
	
	/** The Constant STATUS. */
	public static final String STATUS = "status";
	
	/** The Constant SCREENSHOTS. */
	public static final String SCREENSHOTS = "screenshots";

	/** The Constant EXTENT_REPORT. */
	public static final String EXTENT_REPORT = "extentreport";
	
	/** The Constant LOGS. */
	public static final String LOGS = "logs";
	
	/** The Constant LOG_FILE_NAME. */
	public static final String LOG_FILE_NAME = "log.log";

	/** The Constant DATE_FORMAT_YYYY_MM_DD. */
	public static final String DATE_FORMAT_YYYY_MM_DD = "yyyy/MM/dd";

	/** The Constant TIME_STAMP_FORMAT_DD_MM_YYYY_HH_MM_SS. */
	public static final String TIME_STAMP_FORMAT_DD_MM_YYYY_HH_MM_SS = "dd-MM-yyyy HH mm ss";

	/** The Constant DOUBLE_FORWARD_SLASH. */
	public static final String DOUBLE_FORWARD_SLASH = "\\";

	/** The Constant TEST_RESULTS. */
	public static final String TEST_RESULTS = "testResults";
	
	/** The Constant PASS. */
	public static final String PASS = "Pass";

	/** The Constant FAIL. */
	public static final String FAIL = "Fail";
	
	/** The Constant MM_dd_yyyy. */
	public static final String MM_dd_yyyy = "MM/dd/yyyy";

	/** The Constant LOG4J_FILE_PATH. */
	// LOG4J path
	public static final String LOG4J_FILE_PATH = "\\src\\test\\resources\\config\\log4j.properties";

	/** The Constant HYPHEN. */
	public static final String HYPHEN = "-";

	/** The Constant SPACE. */
	public static final String SPACE = " ";
	
	/** The Constant AMAZONLOGIN_OBJECTREPOSITORY_PROPERTY. */
	public static final String AMAZONLOGIN_OBJECTREPOSITORY_PROPERTY= "\\src\\test\\resources\\properties\\Login.property";
	
	/** The Constant TEST_DATA_PATH. */
	public static final String TEST_DATA_PATH = "\\src\\test\\resources\\testdata\\testData.xlsx";

	/** The Constant CHROME_DRIVER_PATH. */
	public static final String CHROME_DRIVER_PATH = "/src/test/resources/drivers/chromedriver.exe";
	
	/** The Constant CHROME_WEBDRIVER. */
	public static final String CHROME_WEBDRIVER = "webdriver.chrome.driver";
	
	/** The Constant HANDLE_POPUP. */
	public static final String HANDLE_POPUP = "HANDLE_POPUP";
	
	//GEKO
	public static final String GEKO_DRIVER = "webdriver.firefox.marionette";
	/** The Constant GEKO_DRIVER_PATH. */
	public static final String GEKO_DRIVER_PATH = "/src/test/resources/drivers/geckodriver.exe";
	
	// IE
		public static final String IE_DRIVER = "webdriver.ie.driver";

		/** The Constant IE_DRIVER_PATH. */
		public static final String IE_DRIVER_PATH = "/src/test/resources/drivers/iedriver.exe";
		
		/** The Constant EDGE_PATH. */
		public static final String EDGE_PATH = "/src/test/resources/drivers/edgedriver.exe";
	
	// Browsers
		/** The Constant SAFARI. */
		public static final String SAFARI = "safari";

		/** The Constant IE. */
		public static final String IE = "ie";

		/** The Constant CHROME. */
		public static final String CHROME = "chrome";

		/** The Constant MOZILLA_FIREFOX. */
		public static final String MOZILLA_FIREFOX = "firefox";

		/** The Constant EDGE. */
		public static final String EDGE = "edge";
		
		/** The Constant EDGE_DRIVER. */
		// IE_EDGE
		public static final String EDGE_DRIVER = "webdriver.edge.driver";

	
	
	
}
