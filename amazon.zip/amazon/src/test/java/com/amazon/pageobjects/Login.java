package com.amazon.pageobjects;

import org.openqa.selenium.By;

import com.amazon.constants.Constants;
import com.amazon.utils.PropertyUtils;

public class Login {
	public static String baseProjectPath = System.getProperty(Constants.USER_DIR);
	public static PropertyUtils repository = new PropertyUtils(
			baseProjectPath.concat(Constants.AMAZONLOGIN_OBJECTREPOSITORY_PROPERTY));
	public static By hellosign_Field = By.xpath(repository.getProperty("HELLOSIGN_FIELD"));
	public static By email_field = By.xpath(repository.getProperty("EMAIL_FIELD"));
	public static By password_field = By.xpath(repository.getProperty("PASSWORD_FIELD"));
	public static By login_field = By.xpath(repository.getProperty("LOGIN_FIELD"));
	public static By dropdownicon_field = By.xpath(repository.getProperty("DROPDOWNICON_FIELD"));
	public static By signout_field = By.xpath(repository.getProperty("SIGNOUT_FIELD"));
	public static By departments_field = By.xpath(repository.getProperty("DEPARTMENTS_FIELD"));
	public static By electronics_field = By.xpath(repository.getProperty("ELECTRONICS_FIELD"));
	public static By headphones_field = By.xpath(repository.getProperty("HEADPHONES_FIELD"));
	public static By boseheadphone_field = By.xpath(repository.getProperty("BOSEHEADPHONE_FIELD"));
	public static By addtocart_field = By.xpath(repository.getProperty("ADDTOCART_FIELD"));
	public static By search_field = By.xpath(repository.getProperty("SEARCH_FIELD"));
	public static By closebutton_field = By.xpath(repository.getProperty("CLOSEBUTTON_FIELD"));
	public static By searchicon_field = By.xpath(repository.getProperty("SEARCHICON_FIELD"));
	public static By macbookpro_field = By.xpath(repository.getProperty("MACBOOKPRO_FIELD"));
	public static By quantity_field = By.xpath(repository.getProperty("QUANTITY_FIELD"));
	public static By cart_field = By.xpath(repository.getProperty("CART_FIELD"));
	public static By delete_field = By.xpath(repository.getProperty("DELETE_FIELD"));
	public static By quantityselection_field = By.xpath(repository.getProperty("QUANTITYSELECTION_FIELD"));
	public static By quantityselected_field = By.xpath(repository.getProperty("QUANTITYSELECTED_FIELD"));
	public static By proceedtocheckout_field = By.xpath(repository.getProperty("PROCEEDTOCHECKOUT_FIELD"));
	public static By closeicon_field = By.xpath(repository.getProperty("CLOSEICON_FIELD"));
}
