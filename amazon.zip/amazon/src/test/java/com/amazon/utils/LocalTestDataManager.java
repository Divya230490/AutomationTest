package com.amazon.utils;


import java.util.ArrayList;
import java.util.HashMap;



public class LocalTestDataManager {
	/** The testdatahashmap. */
	private static ThreadLocal<HashMap<String, String>> testdatahashmap = new ThreadLocal<HashMap<String, String>>();

	/** The scenarioname. */
	private static ThreadLocal<String> scenarioname = new ThreadLocal<String>();
	
	/** The ExtentReportPath. */
	private static ThreadLocal<String> extentReportPath = new ThreadLocal<String>();
	
	/**
	 * Gets the scenarioname.
	 *
	 * @return the scenarioname
	 */
	public static String getScenarioname() {
		return scenarioname.get();
	}

	/**
	 * Sets the scenarioname.
	 *
	 * @param scenname
	 *            the new scenarioname
	 */
	public static void setScenarioname(String scenname) {
		scenarioname.set(scenname);
	}

	/** The featurename. */
	private static ThreadLocal<String> featurename = new ThreadLocal<String>();

	/**
	 * Gets the featurename.
	 *
	 * @return the featurename
	 */
	public static String getFeaturename() {
		return featurename.get();
	}

	/**
	 * Sets the featurename.
	 *
	 * @param nameFeature
	 *            the new featurename
	 */
	public static void setFeaturename(String nameFeature) {
		featurename.set(nameFeature);
	}

	/** The step number. */
	private static ThreadLocal<Integer> stepNumber = new ThreadLocal<Integer>();

	/**
	 * Gets the step number.
	 *
	 * @return the step number
	 */
	public static Integer getStepNumber() {
		return stepNumber.get();
	}

	/**
	 * Sets the step number.
	 *
	 * @param numberStep
	 *            the new step number
	 */
	public static void setStepNumber(Integer numberStep) {
		stepNumber.set(numberStep);
	}

	/** The scenario status. */
	private static ThreadLocal<String> scenarioStatus = new ThreadLocal<String>();

	/**
	 * Gets the scenario status.
	 *
	 * @return the scenario status
	 */
	public static String getScenarioStatus() {
		return scenarioStatus.get();
	}

	/**
	 * Sets the scenario status.
	 *
	 * @param statusScenario
	 *            the new scenario status
	 */
	public static void setScenarioStatus(String statusScenario) {
		scenarioStatus.set(statusScenario);
	}

	/**
	 * Gets the test data hash map.
	 *
	 * @return the test data hash map
	 */
	public static HashMap<String, String> getTestDataHashMap() {
		return testdatahashmap.get();
	}

	/**
	 * Sets the test data hash map.
	 *
	 * @param data
	 *            the data
	 */
	static void setTestDataHashMap(HashMap<String, String> data) {
		testdatahashmap.set(data);
	}

	/** The scenario ID. */
	private static ThreadLocal<String> scenarioID = new ThreadLocal<String>();

	/**
	 * Gets the scenario ID.
	 *
	 * @return the scenario ID
	 */
	public static String getScenarioID() {
		return scenarioID.get();
	}
	
	/**
	 * Sets the scenario ID.
	 *
	 * @param idScenario
	 *            the new scenario ID
	 */
	public static void setScenarioID(String idScenario) {
		scenarioID.set(idScenario);
	}

	/** The exec result set. */
	private static ThreadLocal<HashMap<String, Integer>> execResultSet = new ThreadLocal<HashMap<String, Integer>>();

	/**
	 * Gets the exec result set.
	 *
	 * @return the exec result set
	 */
	public static HashMap<String, Integer> getExecResultSet() {
		return execResultSet.get();
	}

	/**
	 * Sets the exec result set.
	 *
	 * @param data
	 *            the data
	 */
	static void setExecResultSet(HashMap<String, Integer> data) {
		execResultSet.set(data);
	}

	
	/** The fullmap. */
	private static ThreadLocal<HashMap<String, ArrayList<String>>> fullmap = new ThreadLocal<HashMap<String, ArrayList<String>>>();

	/**
	 * Gets the fullmap.
	 *
	 * @return the fullmap
	 */
	public static HashMap<String, ArrayList<String>> getFullmap() {
		return fullmap.get();
	}

	/**
	 * Sets the fullmap.
	 *
	 * @param _fullmap
	 *            the fullmap
	 */
	public static void setFullmap(HashMap<String, ArrayList<String>> _fullmap) {
		fullmap.set(_fullmap);

	}

	/** The finalmap. */
	private static ThreadLocal<HashMap<String, ArrayList<String>>> finalmap = new ThreadLocal<HashMap<String, ArrayList<String>>>();

	/**
	 * Gets the finalmap.
	 *
	 * @return the finalmap
	 */
	public static HashMap<String, ArrayList<String>> getFinalmap() {
		return finalmap.get();
	}

	/**
	 * Sets the finalmap.
	 *
	 * @param _finalmap
	 *            the finalmap
	 */
	public static void setFinalmap(HashMap<String, ArrayList<String>> _finalmap) {
		finalmap.set(_finalmap);

	}
	public static void setExtentReportPath(String ExtentReportPath) {
		extentReportPath.set(ExtentReportPath);
	}

	public static String getExtentReportPath() {
		return extentReportPath.get();
	}

}
