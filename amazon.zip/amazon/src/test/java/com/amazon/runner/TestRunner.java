package com.amazon.runner;

import org.junit.runner.RunWith;

import com.amazon.constants.Constants;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

/**
 * The Class RunnerTest.

 */
@RunWith(Cucumber.class)
@CucumberOptions(features = Constants.END_TO_END_FEATURES_PATH, glue = {
		Constants.STEP_DEFINITIONS }, tags="@Test")

public class TestRunner {

}
