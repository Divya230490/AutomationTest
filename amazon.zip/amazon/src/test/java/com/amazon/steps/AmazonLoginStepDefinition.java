package com.amazon.steps;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.amazon.config.DriverConfig;
import com.amazon.config.LocalDriverManager;
import com.amazon.pageobjects.Login;
import com.amazon.utils.LocalTestDataManager;
import com.amazon.utils.TestDataUtils;
import com.amazon.utils.TestResultsUtils;
import com.relevantcodes.extentreports.LogStatus;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class AmazonLoginStepDefinition extends TestDataUtils{

	/** The logger. */
	private static final Logger LOG = LoggerFactory.getLogger(DriverConfig.class);
	TestResultsUtils testResultUtils = new TestResultsUtils();
	
	@Given("^I Login to Amazon Application$")
	public void i_Login_to_Amazon_Application() throws Throwable {
		try {
			DriverConfig seleniumObj = new DriverConfig();
			seleniumObj.setUpSuite();
			LOG.info("Access the AMAZON URL::PASS");
			TestResultsUtils.logger.log(LogStatus.PASS, "Login to Amazon Application");

		} catch (Exception exception) {
			exception.getMessage();
		}
	}

	@And("^User clicks on HelloSignIn$")
	public void user_clicks_on_HelloSignIn() throws Throwable {
		try {
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(5000, TimeUnit.MICROSECONDS);
			LocalDriverManager.getDriver().findElement(Login.hellosign_Field).click();
			TestResultsUtils.logger.log(LogStatus.PASS, "User clicks on Hello Sign in Field");
		} catch (Exception exception) {
			exception.getMessage();
		}

	}

	@And("^User enters EmailId \"([^\"]*)\" and Password \"([^\"]*)\"$")
	public void user_enters_EmailId_and_Password(String arg1, String arg2) throws Throwable {
		try {
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(5000, TimeUnit.MICROSECONDS);
			LocalDriverManager.getDriver().findElement(Login.email_field)
					.sendKeys(LocalTestDataManager.getTestDataHashMap().get(arg1));
			TestResultsUtils.logger.log(LogStatus.PASS, "User enters the email id field" + LocalTestDataManager.getTestDataHashMap().get(arg1));
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(5000, TimeUnit.MICROSECONDS);
			LocalDriverManager.getDriver().findElement(Login.password_field)
					.sendKeys(LocalTestDataManager.getTestDataHashMap().get(arg2));
			TestResultsUtils.logger.log(LogStatus.PASS, "User enters the password" + LocalTestDataManager.getTestDataHashMap().get(arg2));
		} catch (Exception exception) {
			exception.getMessage();
		}
	}

	@Then("^User clicks on SignIn button for Login$")
	public void user_clicks_on_SignIn_button_for_Login() throws Throwable {
		try {
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(10000, TimeUnit.MICROSECONDS);
			LocalDriverManager.getDriver().findElement(Login.login_field).click();
			TestResultsUtils.logger.log(LogStatus.PASS, "User clicks on SignIn Button field");
		} catch (Exception exception) {
			exception.getMessage();
		}
	}

	@Then("^User clicks on SignOut button$")
	public void user_clicks_on_SignOut_button() throws Throwable {
		try {
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(5000, TimeUnit.MICROSECONDS);
			Actions action = new Actions(LocalDriverManager.getDriver());
			action.moveToElement(LocalDriverManager.getDriver().findElement(Login.dropdownicon_field)).perform();
			TestResultsUtils.logger.log(LogStatus.PASS, "User hovers on Dropdown field on Username");
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(10000, TimeUnit.MICROSECONDS);
			LocalDriverManager.getDriver().findElement(Login.signout_field).click();
			TestResultsUtils.logger.log(LogStatus.PASS, "User clicks on Sign out field");
		} catch (Exception exception) {
			exception.getMessage();
		}
	}

	@Then("^User hovers on the Department Section$")
	public void user_hovers_on_the_Department_Section() throws Throwable {
		try {
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(5000, TimeUnit.MICROSECONDS);
			Actions action = new Actions(LocalDriverManager.getDriver());
			action.moveToElement(LocalDriverManager.getDriver().findElement(Login.departments_field)).perform();
			TestResultsUtils.logger.log(LogStatus.PASS, "User hovers on Department field");
		} catch (Exception exception) {
			exception.getMessage();
		}
	}

	@Then("^User chooses the Electronics section$")
	public void user_chooses_the_Electronics_section() throws Throwable {
		try {
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(5000, TimeUnit.MICROSECONDS);
			LocalDriverManager.getDriver().findElement(Login.electronics_field).click();
			TestResultsUtils.logger.log(LogStatus.PASS, "User clciks on Electronics field");
		} catch (Exception exception) {
			exception.getMessage();
		}
	}

	@Then("^User chooses the Headphones option$")
	public void user_chooses_the_Headphones_option() throws Throwable {
		try {
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(5000, TimeUnit.MICROSECONDS);
			LocalDriverManager.getDriver().findElement(Login.headphones_field).click();
			TestResultsUtils.logger.log(LogStatus.PASS, "User clciks on Headphones field");
		} catch (Exception exception) {
			exception.getMessage();
		}
	}

	@Then("^User chooses the first headphone from all options$")
	public void user_chooses_the_first_headphone_from_all_options() throws Throwable {
		try {
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(5000, TimeUnit.MICROSECONDS);
			LocalDriverManager.getDriver().findElement(Login.boseheadphone_field).click();
			TestResultsUtils.logger.log(LogStatus.PASS, "User clciks on Base headphone field");
		} catch (Exception exception) {
			exception.getMessage();
		}
	}

	@Then("^User clicks on Add to Cart button$")
	public void user_clicks_on_Add_to_Cart_button() throws Throwable {
		try {
			 WebDriverWait wait = new WebDriverWait(LocalDriverManager.getDriver(), 10);
			 wait.until(ExpectedConditions.presenceOfElementLocated(Login.addtocart_field));
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(20000, TimeUnit.MICROSECONDS);
			if (LocalDriverManager.getDriver().findElement(Login.addtocart_field).isDisplayed()) {
				LocalDriverManager.getDriver().findElement(Login.addtocart_field).click();
				 TestResultsUtils.logger.log(LogStatus.PASS, "User clicks on Add to Cart field");
			}
			
		} catch (Exception e) {
			e.getMessage();
		}
	}
	
	@Then("^User clicks on Close button$")
	public void user_clicks_on_Close_button() throws Throwable {
		try {
		WebDriverWait wait = new WebDriverWait(LocalDriverManager.getDriver(), 15);
		wait.until(ExpectedConditions.presenceOfElementLocated(Login.closebutton_field));
		LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(10000, TimeUnit.MICROSECONDS);		
		LocalDriverManager.getDriver().findElement(Login.closebutton_field).click();
		TestResultsUtils.logger.log(LogStatus.PASS, "User clicks on Close Button field");
		}
		catch (Exception e) {
			e.getMessage();
		}

		
	}


	@Then("^User enters Macbook Pro\"([^\"]*)\" in Search bar$")
	public void user_enters_Macbook_Pro_in_Search_bar(String arg1) throws Throwable {
		LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(5000, TimeUnit.MICROSECONDS);
		LocalDriverManager.getDriver().findElement(Login.search_field)
				.sendKeys(LocalTestDataManager.getTestDataHashMap().get(arg1));
		TestResultsUtils.logger.log(LogStatus.PASS, "User enters value in search bar field"+LocalTestDataManager.getTestDataHashMap().get(arg1));

	}

	@Then("^User clicks on Search Icon$")
	public void user_clicks_on_Search_Icon() throws Throwable {
		try {
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(5000, TimeUnit.MICROSECONDS);
			LocalDriverManager.getDriver().findElement(Login.searchicon_field).click();
			TestResultsUtils.logger.log(LogStatus.PASS, "User clicks on search icon field");
		} catch (Exception e) {
			e.getMessage();
		}
	}

	@Then("^User selects the second option in Macbook Pro$")
	public void user_selects_the_second_option_in_Macbook_Pro() throws Throwable {
		try {
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(5000, TimeUnit.MICROSECONDS);
			LocalDriverManager.getDriver().findElement(Login.macbookpro_field).click();
			TestResultsUtils.logger.log(LogStatus.PASS, "User clicks on second option for Macbook Pro");
		} catch (Exception e) {
			e.getMessage();
		}
	}

	@Then("^User selects the quantity for Macbook Pro$")
	public void user_selects_the_quantity_for_Macbook_Pro() throws Throwable {
		try {
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(10000, TimeUnit.MICROSECONDS);			
			Select listbox = new Select(LocalDriverManager.getDriver().findElement(Login.quantity_field));
			listbox.selectByVisibleText("2");
			TestResultsUtils.logger.log(LogStatus.PASS, "User selects the quantity for Macbook Pro");
		} catch (Exception e) {
			e.getMessage();
		}

	}

	@Then("^User clicks on Close Icon Field$")
	public void user_clicks_on_Close_Icon_Field() throws Throwable {
		try {
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(5000, TimeUnit.MICROSECONDS);
			LocalDriverManager.getDriver().findElement(Login.closeicon_field).click();
			TestResultsUtils.logger.log(LogStatus.PASS, "User clicks on the Close Icon field");
		} catch (Exception e) {
			e.getMessage();
		}
	}

	

	@Then("^User clicks on Add to Cart button for Macbook Pro$")
	public void user_clicks_on_Add_to_Cart_button_for_Macbook_Pro() throws Throwable {
		try {
			WebDriverWait wait = new WebDriverWait(LocalDriverManager.getDriver(), 30);
			wait.until(ExpectedConditions.presenceOfElementLocated(Login.addtocart_field));
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(20000, TimeUnit.MICROSECONDS);
			if (LocalDriverManager.getDriver().findElement(Login.addtocart_field).isDisplayed()) {
				LocalDriverManager.getDriver().findElement(Login.addtocart_field).click();
				TestResultsUtils.logger.log(LogStatus.PASS, "User clicks on Add to Cart field");
			}
		} catch (Exception e) {
			e.getMessage();
		}
	}
	
	@Then("^User clicks on Cart button$")
	public void user_clicks_on_Cart_button() throws Throwable {
		try {
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(5000, TimeUnit.MICROSECONDS);
			LocalDriverManager.getDriver().findElement(Login.cart_field).click();
			TestResultsUtils.logger.log(LogStatus.PASS, "User clicks on Cart field");
		} catch (Exception e) {
			e.getMessage();
		}
	}

	@Then("^User clicks on ProceedToCart button$")
	public void user_clicks_on_ProceedToCart_button() throws Throwable {
		try {
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(5000, TimeUnit.MICROSECONDS);
			LocalDriverManager.getDriver().findElement(Login.proceedtocheckout_field).click();
			TestResultsUtils.logger.log(LogStatus.PASS, "User clicks on Proceed to checkout field");
		} catch (Exception e) {
			e.getMessage();
		}
	}
	@Then("^User clicks on quantity dropdown$")
	public void user_clicks_on_quantity_dropdown() throws Throwable {
		try {
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(5000, TimeUnit.MICROSECONDS);
			LocalDriverManager.getDriver().findElement(Login.quantityselection_field).click();
			TestResultsUtils.logger.log(LogStatus.PASS, "User clicks on Quantity selection field");
		} catch (Exception e) {
			e.getMessage();
		}
	}

	@Then("^User reduces the quantity for Macbook Pro$")
	public void user_reduces_the_quantity_for_Macbook_Pro() throws Throwable {
		try {
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(10000, TimeUnit.MICROSECONDS);
			LocalDriverManager.getDriver().findElement(Login.quantityselected_field).click();
			TestResultsUtils.logger.log(LogStatus.PASS, "User reduces the quantity for Macbook Pro");
		} catch (Exception e) {
			e.getMessage();
		}
	}

	@Then("^User clicks on delete button$")
	public void user_clicks_on_delete_button() throws Throwable {
		try {
			LocalDriverManager.getDriver().manage().timeouts().implicitlyWait(10000, TimeUnit.MICROSECONDS);
			LocalDriverManager.getDriver().findElement(Login.delete_field).click();
			TestResultsUtils.logger.log(LogStatus.PASS, "User clicks on delete button for headphones");
		} catch (Exception e) {
			e.getMessage();
		}
	}



}
