package com.amazon.steps;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.amazon.utils.TestDataUtils;
import com.amazon.utils.TestResultsUtils;
import com.amazon.steps.BeforeAfterStepDefinition;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class BeforeAfterStepDefinition extends TestDataUtils{

	/** The logger. */
	private static final Logger LOG = LoggerFactory.getLogger(BeforeAfterStepDefinition.class);
	TestResultsUtils testResultUtils = new TestResultsUtils();
	
	@Before
	public void beforetest(Scenario scenario) throws Throwable {
		try {
			TestResultsUtils.outputFolder();
			TestResultsUtils.extentReportInitialize();
			TestResultsUtils.logger = TestResultsUtils.extent.startTest(scenario.getName());
			LOG.info("In before step definition for scenario::{}", scenario.getName());
			readTestData(scenario);
		
		} catch (Exception exception) {
			LOG.error("Scenario::{}-Error in execution of before testException is ::{}", scenario.getName(),
					exception.getMessage());
		}
	}
	@After
	public void close() throws Throwable {
		try {		
			tearDown();
			TestResultsUtils.extentReportFlush();
			TestResultsUtils.extentReportClose();
			
		} catch (Exception exception) {
			LOG.error("Error in In After Block execution::{}", exception);
			throw exception;
		}
	}
}
